# spacex-platzi
A web application that shows info of SpaceX, using [spaceX rest API](https://github.com/r-spacex/SpaceX-API) 

Live [Demo](https://platzinautas.now.sh/)
