# Guía de estilo de front-end

## Diseño

Los diseños se crearon con los siguientes anchos:

- Mobile: 375px
- Desktop: 1440px


## Colores

### Primario

Rojo brillante: rgb (242, 95, 58)
Azul oscuro: rgb (35, 44, 81)

### Neutro

Azul grisáceo oscuro: rgb (143, 148, 167)
Azul muy oscuro: rgb (29, 30, 37)
Rojo muy pálido: rgb (255, 239, 234)
Variante gris claro: rgb (249, 249, 249)

## Tipografia

### Body Copy

- Font size: 16px

### Font

- Family: [Be Vietnam](https://fonts.google.com/specimen/Be+Vietnam)
- Weights: 400, 500, 700

## Icons

Para los íconos sociales, puede usar los íconos provistos o una biblioteca de íconos de fuentes. Ej:

- [Font Awesome](https://fontawesome.com)
