import estados.TamagochiState;

public class Main {
    public static void main(String[] args) {
        Tamagochi tamagochi = new Tamagochi();

        tamagochi.darDeComer();
        tamagochi.darDeComer();
        tamagochi.darMimos();
        tamagochi.darMimos();
        tamagochi.darDeBeber();
    }
}