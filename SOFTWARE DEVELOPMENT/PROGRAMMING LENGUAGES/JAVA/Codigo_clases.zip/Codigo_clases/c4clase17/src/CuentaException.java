public class CuentaException extends Exception{

    public CuentaException(String message) {
        super(message);
    }
}
