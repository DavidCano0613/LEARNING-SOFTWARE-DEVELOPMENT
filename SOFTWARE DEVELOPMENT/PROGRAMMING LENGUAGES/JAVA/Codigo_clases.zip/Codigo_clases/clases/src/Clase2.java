//public class Clase2 {
//
//    public static void main(String[] args) {
//
//        boolean resultado = numeroPrimo(67);
//
//
//    }
//
//    public static boolean numeroPrimo(Integer num){
//        int cociente = 0;
//        for (int i = 1; i <= num; i++) {
//            if(num % i == 0){
//                cociente ++;
//            }
//            else{
//                cociente = cociente;
//            }
//        }
//        if(cociente > 2){
//            System.out.println(num + " no es primo");
//            return false;
//        }
//        else{
//            System.out.println(num + " es primo");
//            return true;
//        }
//
//    }
//
//}
