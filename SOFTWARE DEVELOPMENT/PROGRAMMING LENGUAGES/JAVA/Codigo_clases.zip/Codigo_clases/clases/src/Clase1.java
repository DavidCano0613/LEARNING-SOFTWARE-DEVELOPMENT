//public class Clase1 {
//
//    public static void main(String[] args) {
//
//        public static void main(String[] args) {
//
//            /* String mascotaUno = "Perro";
//            String nombreUno = "Manchitas";
//            int edadUno = 2;
//            double comidaUno = 1.5;
//            String sonidoUno = "guau guau";
//
//            String mascotaDos = "Pez";
//            String nombreDos = "Nemo";
//            int edadDos = 1;
//            double comidaDos = 0.14;
//            String sonidoDos = "gluu gluu";
//
//            String mascotaTres = "Gato";
//            String nombreTres = "Silvestre";
//            int edadTres = 3;
//            double comidaTres = 0.5;
//            String sonidoTres = "miau miau";
//
//            String mascotaCuatro = "Tortuga";
//            String nombreCuatro = "Manuelita";
//            int edadCuatro = 12;
//            double comidaCuatro = 0.3;
//            String sonidoCuatro = "umm";
//
//            String mascotaQuinto = "Canario";
//            String nombreQuinto = "Gardel";
//            int edadQuinto = 1;
//            double comidaQuinto = 0.35;
//            String sonidoQuinto = "pio pio";
//
//
//            System.out.println(nombreUno + " tiene " + edadUno + " años");
//            System.out.println(nombreUno + " come " + comidaUno + " kilo" + " y hace " + sonidoUno);
//
//            System.out.println(nombreDos + " tiene " + edadDos + " año");
//            System.out.println(nombreDos + " come " + comidaDos + " kilo" + " y hace " + sonidoDos);
//
//            System.out.println(nombreTres + " tiene " + edadTres + " años");
//            System.out.println(nombreTres + " come " + comidaTres + " kilo" + " y hace " + sonidoTres);
//
//            System.out.println(nombreCuatro + " tiene " + edadCuatro + " años");
//            System.out.println(nombreCuatro + " come " + comidaCuatro + " kilo" + " y hace " + sonidoCuatro);
//
//            System.out.println(nombreQuinto + " tiene " + edadQuinto + " año");
//            System.out.println(nombreQuinto + " come " + comidaQuinto + " kilo" + " y hace " + sonidoQuinto);*/
//        }
//
//
//
//
//        /* Scanner scanner;
//            scanner = new Scanner(System.in);
//
//            int num3;
//            int num4;
//            float coeficiente;
//            String nombre;
//            System.out.println("Ingrese su nombre");
//            nombre = scanner.nextLine();
//            char inicial;
//
//            System.out.println("Ingrese el primer valor");
//            num3 = scanner.nextInt();
//            System.out.println("Ingrese el segundo valor");
//            num4 = scanner.nextInt();
//            System.out.println("Ingrese el coeficiente");
//            coeficiente = scanner.nextFloat();
//            inicial = nombre.charAt(0);
//            System.out.println(inicial);
//
//
//            */
//
///*            int resultado = sumar(1,2);
//            System.out.println(resultado);
//    }
//
//    public static int sumar( int a, int b){
//
//        return a + b;*/
//
//
//        boolean resultado = numeroPrimo(67);
//
//
//    }
//
//    public static boolean numeroPrimo(Integer num){
//        int cociente = 0;
//        for (int i = 1; i <= num; i++) {
//            if(num % i == 0){
//                cociente ++;
//            }
//            else{
//                cociente = cociente;
//            }
//        }
//        if(cociente > 2){
//            System.out.println(num + " no es primo");
//            return false;
//        }
//        else{
//            System.out.println(num + " es primo");
//            return true;
//        }
//
//    }
//
//}

