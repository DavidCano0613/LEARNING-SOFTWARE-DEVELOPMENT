public interface Comprable {

    public Double calcularPrecio();
}
