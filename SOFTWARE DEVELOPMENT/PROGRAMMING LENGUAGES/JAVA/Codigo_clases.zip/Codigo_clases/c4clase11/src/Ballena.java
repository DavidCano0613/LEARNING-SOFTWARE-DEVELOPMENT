public class Ballena extends Animal{

    public Ballena(String nombre, String color) {
        super(nombre, color);
    }

    @Override
    public void hacerRuido() {

    }
}
