public class Cliente {

    private Integer numeroDeCliente;
    private String apellido;

    public Cliente(Integer numeroDeCliente, String apellido) {
        this.numeroDeCliente = numeroDeCliente;
        this.apellido = apellido;
    }
}
