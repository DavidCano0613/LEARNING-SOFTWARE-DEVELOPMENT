public interface TransporteStrategy {

    public Double calcularTiempoRecorrido(Double distancia);
}
