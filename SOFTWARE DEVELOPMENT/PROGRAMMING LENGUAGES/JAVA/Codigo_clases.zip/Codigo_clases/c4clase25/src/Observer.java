public interface Observer {

    public void actualizar(Usuario usuario);
}
