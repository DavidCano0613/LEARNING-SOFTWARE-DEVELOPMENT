public class Main {

    public static void main(String[] args) {

        // console.log
        System.out.println("hola mundo");

        // declaracion de variables let


        String nombre = "Carlos";

        Integer edad = 22;

        Double altura = 1.75;

        Boolean estaLloviendo = true;

        System.out.println("mi nombre es " + nombre + " y mido " + altura + " metros");

        //Condicionales

        if(altura > 1.40){
            System.out.println("puede subir");
        }else{
            System.out.println("no puede subir");
        }





    }
}
