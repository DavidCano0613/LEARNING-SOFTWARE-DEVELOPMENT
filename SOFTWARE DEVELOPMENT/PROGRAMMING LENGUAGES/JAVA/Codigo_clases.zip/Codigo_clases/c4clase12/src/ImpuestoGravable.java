public interface ImpuestoGravable {

    public Double gravarImpuesto(Double porcentaje);
}
