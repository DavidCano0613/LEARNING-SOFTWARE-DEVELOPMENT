
public class UnidadesFactoryExcepcion extends Exception {

    public UnidadesFactoryExcepcion(String message) {
        super(message);
    }
}
