public class Capitan {

    private String nombre;
    private String apellido;
    private Integer matricula;

    public Capitan(String nombre, String apellido, Integer matricula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.matricula = matricula;
    }
}
