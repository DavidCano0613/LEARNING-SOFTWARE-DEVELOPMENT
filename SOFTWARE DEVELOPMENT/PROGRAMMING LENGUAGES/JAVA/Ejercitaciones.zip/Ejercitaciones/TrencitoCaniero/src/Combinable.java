public interface Combinable {

    public Double calcularArea();
}
