public interface Observer {

    public void actualizar(Subasta subasta);
}
