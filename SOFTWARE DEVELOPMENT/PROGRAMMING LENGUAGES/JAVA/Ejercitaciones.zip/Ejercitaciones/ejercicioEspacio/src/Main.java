public class Main {
    public static void main(String[] args) {
    ObjetoGrafico nuevaNave = new ObjetoGrafico(0,0,'n');
    nuevaNave.irA(0,-10, ' ');
    }
}
