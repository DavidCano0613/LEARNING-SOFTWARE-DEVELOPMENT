public class Main {

    public static void main(String[] args){

        Juego juego1 = new Juego("Daniela", "123");

        juego1.aumentarPuntaje();
        juego1.subirNivel();
        juego1.bonus(5);

    }
}
