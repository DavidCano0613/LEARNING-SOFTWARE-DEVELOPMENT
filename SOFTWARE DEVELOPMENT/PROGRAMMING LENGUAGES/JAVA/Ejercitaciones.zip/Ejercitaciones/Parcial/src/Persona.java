public class Persona {

    private String nombre;
    private String apellido;
    private Integer edad;
    private String dni;

    public Persona(String nombre, String apellido, Integer edad, String dni) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.dni = dni;
    }
}
