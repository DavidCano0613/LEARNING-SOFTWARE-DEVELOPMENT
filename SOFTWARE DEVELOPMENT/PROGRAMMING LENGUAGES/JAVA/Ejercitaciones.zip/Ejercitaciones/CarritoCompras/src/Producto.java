public class Producto {

    private String descripcion;
    private Double precio;
}
