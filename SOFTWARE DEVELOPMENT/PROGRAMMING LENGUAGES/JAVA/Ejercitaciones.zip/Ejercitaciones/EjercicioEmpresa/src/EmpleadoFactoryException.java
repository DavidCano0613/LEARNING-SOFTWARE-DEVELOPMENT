public class EmpleadoFactoryException extends Exception {

    //Se crea la exception y se crea el constructor de la clase con un mensaje
    public EmpleadoFactoryException(String message) {
        super(message);
    }
}
