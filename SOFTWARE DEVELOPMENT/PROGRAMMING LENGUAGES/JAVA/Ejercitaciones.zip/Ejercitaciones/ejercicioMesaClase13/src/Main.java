public class Main {
    public static void main(String[] args) {

        RobotPesado robot1 = new RobotPesado(100);
        robot1.mostrar();

    }
}