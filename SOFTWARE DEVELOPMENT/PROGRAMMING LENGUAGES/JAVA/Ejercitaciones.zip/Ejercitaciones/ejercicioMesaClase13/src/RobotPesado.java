public class RobotPesado extends SistemaArmas implements Atacar, Volar, Defender{

    public RobotPesado(Integer energia) {
        super(energia);
    }

    //METODOS


    @Override
    public void Atacar() {

    }

    @Override
    public void Volar() {

    }

    @Override
    public void Defender() {

    }
}
