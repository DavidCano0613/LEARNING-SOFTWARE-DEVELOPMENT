public class SistemaArmas {
    private Integer energia;

    //CONSTRUCTOR

    public SistemaArmas(Integer energia) {
        this.energia = energia;
    }

    //METODOS
    public void mostrar(){
        System.out.println(energia);
    }
}
