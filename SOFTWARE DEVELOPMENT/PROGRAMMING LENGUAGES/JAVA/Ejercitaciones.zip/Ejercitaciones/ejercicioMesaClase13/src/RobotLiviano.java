public class RobotLiviano extends SistemaArmas implements Atacar, Volar, Defender{

    public RobotLiviano(Integer energia) {
        super(energia);
    }

    @Override
    public void Atacar() {

    }

    @Override
    public void Volar() {

    }

    @Override
    public void Defender() {

    }
}
