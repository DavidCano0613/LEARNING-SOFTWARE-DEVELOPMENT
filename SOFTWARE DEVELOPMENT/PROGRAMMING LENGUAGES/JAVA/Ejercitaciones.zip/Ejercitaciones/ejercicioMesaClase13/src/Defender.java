public interface Defender {

    public void Defender();
}
