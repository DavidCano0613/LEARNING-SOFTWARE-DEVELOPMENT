public interface Atacar {
    //METODOS
    public void Atacar ();
}
