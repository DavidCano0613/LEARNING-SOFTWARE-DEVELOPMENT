public class Senuelo extends SistemaArmas{
    public Senuelo(Integer energia) {
        super(energia);
    }

}
