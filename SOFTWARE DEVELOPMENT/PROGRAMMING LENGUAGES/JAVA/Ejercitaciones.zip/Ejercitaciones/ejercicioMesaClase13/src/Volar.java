public interface Volar {

    public void Volar();
}
