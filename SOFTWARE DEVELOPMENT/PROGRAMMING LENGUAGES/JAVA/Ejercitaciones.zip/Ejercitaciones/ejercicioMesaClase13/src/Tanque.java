public class Tanque extends SistemaArmas implements Atacar, Defender{

    public Tanque(Integer energia) {
        super(energia);
    }

    @Override
    public void Atacar() {
        
    }

    @Override
    public void Defender() {

    }
}
