public interface StrategyPago {
    void pago();
}
